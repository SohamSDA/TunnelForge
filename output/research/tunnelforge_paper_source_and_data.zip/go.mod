module github.com/SohamSDA/TunnelForge

go 1.26.5

require github.com/gorilla/websocket v1.5.3
